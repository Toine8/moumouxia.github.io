<?php
App::uses('CakeEvent', 'Event');

class Lostpassword extends AppModel
{

    public $belongsTo = 'User';

}
