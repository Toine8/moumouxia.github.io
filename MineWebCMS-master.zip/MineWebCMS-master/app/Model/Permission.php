<?php

class Permission extends AppModel
{
}