<?php

class Page extends AppModel
{
}
