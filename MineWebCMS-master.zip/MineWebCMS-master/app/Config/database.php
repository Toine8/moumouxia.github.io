<?php

class DATABASE_CONFIG
{

    public $default = [
        'datasource' => 'Database/Mysql',
        'persistent' => false,
        'host' => 'localhost',
        'login' => 'LOGIN1',
        'password' => 'PASSWORD1',
        'database' => 'DATABASE1',
        'encoding' => 'utf8',
    ];
}
