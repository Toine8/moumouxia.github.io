<?php

class Seo extends AppModel
{

    public $useTable = "seo";
}